# realTime Chat App - Flask, SocketIO

This is a simple chat application which uses Python, Flask and Socket IO. 

